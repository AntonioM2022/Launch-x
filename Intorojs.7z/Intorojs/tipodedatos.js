//Tipos de datos en JavaScript
let variable = 42 //Número entero o int(number)
console.log(typeof variable);
variable= "42";
console.log(typeof variable);
variable= 42;
console.log(variable + variable);
variable= !false; //booleano
console.log(variable);