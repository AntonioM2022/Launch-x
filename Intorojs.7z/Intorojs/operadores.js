let lista= [];

let x= 5 //operadores de asignacion
let y= 10

//Asignacion de adición
x +=y // Es exactamente lo mismo que hacer: x = x+y
x +=y

lista.push(x)
console.log(lista)
y -=x

console.push(y)
console.log(lista)

//Asignacion de multiplicación
x *= y
lista.push(x)
console.log(lista)

x= 5
y= 10
//operador de bit a bit de desplazamiento a la izquierda
x <<= y

lista.push(x)
console.log(lista)

x= 5
y= 10
//Asignacion de modulo o residuo
console.log(y % x)

y %= x

console.push(y)
console.log(lista)

//Estructura de control if
let var1=3;
let var2= 4;

//operador igual
if (var1 == '3'){
    console.log("Son iguales");
}else{
    console.log("No son iguales")
}

//operador estrictamente igual
if (var1 === '3'){
    console.log("Son iguales");
}else{
    console.log("No son iguales")
}

//Operador de desgualdad
if (var1 != var2){
    console.log("Son diferentes");
}else{
    console.log("No son diferentes")
}

//Operador de desigualdad estricta
if (var1 !== var2){
    console.log("Son diferentes");
}else{
    console.log("No son diferentes")
}

//>mayor que
console.log(var1 > var2);
