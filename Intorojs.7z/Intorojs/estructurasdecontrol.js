/*
//ciclo for
for (let i= 0; i < 9; i++){
    if((i%2)!=0){
        continue;
    }
    if(i == 10){
        break;
    }
    console.log(i)
}
    console.log("Aqui ya me salí :3")

    var1= null;
    var3= "";
    var4=0;
    var5=false;
    var6=undefined;



    console.log(var1);
    console.log(var3);
    console.log(var4);
    console.log(var5);
    console.log(var6 + var6);

    console.log("-------------------------------");
    
    //if else-else if
    function validarEdad(edad){
        if (confirm('Estas de acuerdo con seguir con esto')){
            console.log("Sigue bajo tu propio riesgo");
        if ( edad>= 18 && edad <= 150){
            console.log("Ya puedes comprar cigarritos");
            }else if(edad > 150){
                console.log("Saludame a cepillin");
            }else if(edad >= 0){
                console.log("Estas muy peque vuelve en unos años");
            }else{
                console.log("Tu no deberias existir");
            }
        } else{
            console.log("Que miedoso .....XD")
        }

    }
    
    
    function mandarMensajes(edad){
    console.log(typeof edad);
    
    switch(edad){
    case 13 : 
        console.log("Deberias estar en secundaria");
        break;
    case 17:
        console.log("Espera un año mas");
        break;
    case 5:
            validarEdad(edad);
            break;
    default:
            console.log("UwU");
    }
    }

    //if else
    let edad= prompt("Introduce tu edad");
    if (edad && !isNaN(edad)){//con el isNaN checamos si es un numero
        edad=Number(edad);

        validarEdad(edad);
        mandarMensajes(edad);
    }else{
        alert("Debes introducir tu edad");
        location.reload();
    }
    */

   //-------------------------------------------------
   //while
   let boletosDisponibles = 10;
/*
   while(boletosDisponibles > 0){
    console.log("Boleto comprado para el corona capital");
    boletosDisponibles --;
    console.log("Quedan : " + boletosDisponibles);
    console.log("-------------------------------");
}
*/
//Do while (Al menos se ejecuta una vez)
do{
    console.log("Boleto comprado para el corona capital");
    boletosDisponibles --;
    console.log("Quedan : " + boletosDisponibles);

}while(boletosDisponibles>0);


//--------------------------------------------------
//Try Catch Finally
try{
   //Codigo suseptible a fallar
   balidarEdad(edad); 
}catch(error){
    console.info("validar edad no existe")
} finally{
    console.warn("Tu crush no te quiere")
}

  